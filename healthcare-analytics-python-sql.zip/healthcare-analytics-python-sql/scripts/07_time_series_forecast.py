import pandas as pd
from sqlalchemy import create_engine
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

conn_str = "mssql+pyodbc://@SMASH/HealthcareAnalytics?driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes"
engine = create_engine(conn_str)

# Get daily admissions
query = """
SELECT 
    AdmissionDate,
    COUNT(*) AS DailyAdmissions
FROM FactEncounter
GROUP BY AdmissionDate
ORDER BY AdmissionDate
"""
df = pd.read_sql(query, engine)
df.index = pd.to_datetime(df['AdmissionDate'])
ts = df['DailyAdmissions'].asfreq('D').fillna(0)

# Stationarity test
result = adfuller(ts)
print(f'ADF Statistic: {result[0]:.4f}, p-value: {result[1]:.4f}')

# Fit ARIMA (auto-select could be used, but manual for demo)
model = ARIMA(ts, order=(2,1,2))  # p,d,q
fitted = model.fit()
print(fitted.summary())

# Forecast next 30 days
forecast = fitted.forecast(steps=30)
forecast_index = pd.date_range(start=ts.index[-1] + pd.Timedelta(days=1), periods=30, freq='D')

# Plot historical and forecast
plt.figure(figsize=(12,6))
plt.plot(ts.index, ts, label='Historical')
plt.plot(forecast_index, forecast, label='Forecast', color='red')
plt.fill_between(forecast_index, forecast - 1.96*fitted.get_forecast(steps=30).se_mean, 
                 forecast + 1.96*fitted.get_forecast(steps=30).se_mean, alpha=0.2, color='red')
plt.title('Daily Admissions Forecast (ARIMA)')
plt.xlabel('Date')
plt.ylabel('Admissions')
plt.legend()
plt.savefig('../outputs/forecast.png')
plt.close()

# Save forecast
forecast_df = pd.DataFrame({'Date': forecast_index, 'Forecast': forecast})
forecast_df.to_csv('../outputs/admission_forecast.csv', index=False)
print("✅ Time series forecast complete.")

