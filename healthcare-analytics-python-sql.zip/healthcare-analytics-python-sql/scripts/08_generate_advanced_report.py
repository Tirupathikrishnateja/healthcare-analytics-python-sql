import pandas as pd
import matplotlib.pyplot as plt
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
from datetime import datetime
import os

os.makedirs('../outputs', exist_ok=True)

# Load statistical results
results = pd.read_pickle('../outputs/statistical_results.pkl')
cox_df = pd.read_csv('../outputs/cox_summary.csv')
forecast_df = pd.read_csv('../outputs/admission_forecast.csv')

pdf_filename = f"../outputs/Healthcare_Analytics_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
doc = SimpleDocTemplate(pdf_filename, pagesize=landscape(letter))
styles = getSampleStyleSheet()
story = []

# Title
title_style = ParagraphStyle('CustomTitle', parent=styles['Title'], fontSize=20, textColor=colors.darkblue)
story.append(Paragraph("Healthcare Analytics Report: Clinical Outcomes & Operational Forecasting", title_style))
story.append(Spacer(1, 12))
story.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
story.append(Spacer(1, 12))

# Executive Summary
story.append(Paragraph("Executive Summary", styles['Heading2']))
story.append(Paragraph(f"• Readmission Prediction Model AUC: {results['auc']:.3f}", styles['Normal']))
story.append(Paragraph(f"• Statistically significant predictors (p<0.05): {', '.join([k for k,v in results['p_values'].items() if v<0.05])}", styles['Normal']))
story.append(Paragraph(f"• ANOVA Age difference by readmission: p={results['anova_p']:.4f}", styles['Normal']))
story.append(Spacer(1, 12))

# ROC Curve
story.append(Paragraph("Predictive Model Performance", styles['Heading2']))
story.append(Image('../outputs/roc_curve.png', width=6*inch, height=4*inch))
story.append(Spacer(1, 12))

# Survival Curves
story.append(Paragraph("Survival Analysis: Time to Readmission", styles['Heading2']))
story.append(Image('../outputs/km_curves.png', width=6*inch, height=4*inch))
story.append(Spacer(1, 12))
story.append(Paragraph("Cox Proportional Hazards Results", styles['Heading3']))
# Cox table
cox_table_data = [['Variable', 'Hazard Ratio', 'p-value']]
for _, row in cox_df.iterrows():
    cox_table_data.append([row['covariate'], f"{row['exp(coef)']:.2f}", f"{row['p']:.4f}"])
t = Table(cox_table_data)
t.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,0), colors.grey), ('GRID', (0,0), (-1,-1), 1, colors.black)]))
story.append(t)
story.append(Spacer(1, 12))

# Forecast plot
story.append(Paragraph("Admission Volume Forecast (Next 30 Days)", styles['Heading2']))
story.append(Image('../outputs/forecast.png', width=6*inch, height=4*inch))
story.append(Spacer(1, 12))

# Recommendations
story.append(Paragraph("Clinical Recommendations", styles['Heading2']))
story.append(Paragraph("• Target high-risk patients (CKD, age>75, prior readmission) for discharge planning", styles['Normal']))
story.append(Paragraph("• Implement follow-up calls within 48 hours for patients on Beta Blockers", styles['Normal']))
story.append(Paragraph("• Adjust staffing based on forecasted peak admission days", styles['Normal']))

doc.build(story)
print(f"✅ Comprehensive report generated: {pdf_filename}")

