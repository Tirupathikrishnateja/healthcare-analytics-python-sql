USE HealthcareAnalytics;
GO

-- Corrected Patient risk view (cast BIT to INT for MAX)
CREATE OR ALTER VIEW vw_PatientRisk AS
SELECT 
    p.PatientID,
    p.Age,
    p.Gender,
    p.Diabetes,
    p.Hypertension,
    p.COPD,
    p.CKD,
    p.BMI,
    COUNT(e.EncounterID) AS TotalEncounters,
    AVG(CAST(e.LengthOfStay AS DECIMAL(10,2))) AS AvgLOS,
    MAX(CAST(e.Readmitted30Day AS INT)) AS EverReadmitted,
    AVG(CAST(l.AbnormalFlag AS DECIMAL(10,2))) AS AbnormalLabRatio
FROM DimPatient p
LEFT JOIN FactEncounter e ON p.PatientID = e.PatientID
LEFT JOIN FactLabResult l ON e.EncounterID = l.EncounterID
GROUP BY p.PatientID, p.Age, p.Gender, p.Diabetes, p.Hypertension, p.COPD, p.CKD, p.BMI;
GO

-- Treatment effectiveness summary (no BIT issue here, but good to ensure types)
CREATE OR ALTER VIEW vw_TreatmentOutcome AS
SELECT 
    m.DrugClass,
    COUNT(DISTINCT e.EncounterID) AS NumEncounters,
    AVG(CASE WHEN e.Readmitted30Day = 1 THEN 1.0 ELSE 0 END) AS ReadmissionRate,
    AVG(CAST(e.LengthOfStay AS DECIMAL(10,2))) AS AvgLOS,
    AVG(CASE WHEN e.MortalityFlag = 1 THEN 1.0 ELSE 0 END) AS MortalityRate
FROM FactMedication m
JOIN FactEncounter e ON m.EncounterID = e.EncounterID
GROUP BY m.DrugClass;
GO