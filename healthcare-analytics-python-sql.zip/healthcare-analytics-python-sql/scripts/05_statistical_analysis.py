# 05_statistical_analysis.py (Fully robust)
import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, roc_curve
from scipy import stats
import statsmodels.api as sm
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# Connection
conn_str = "mssql+pyodbc://@SMASH/HealthcareAnalytics?driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes"
engine = create_engine(conn_str)

# Load data from view
df = pd.read_sql("SELECT * FROM vw_PatientRisk", engine)

# Load target (Readmitted30Day) from encounters
df_target = pd.read_sql("SELECT PatientID, MAX(CAST(Readmitted30Day AS INT)) AS Target FROM FactEncounter GROUP BY PatientID", engine)
df = df.merge(df_target, on='PatientID', how='inner')

# Display columns and first few rows for debugging (optional)
print("Columns:", df.columns.tolist())
print("\nFirst 2 rows:")
print(df.head(2))

# Define feature columns (only numeric ones)
feature_cols = ['Age', 'Diabetes', 'Hypertension', 'COPD', 'CKD', 'BMI', 'TotalEncounters', 'AvgLOS', 'AbnormalLabRatio']

# Ensure all feature columns exist; if missing, drop from list
feature_cols = [col for col in feature_cols if col in df.columns]

# Convert each feature column to numeric (coerce errors -> NaN)
for col in feature_cols:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# Convert target to int
df['Target'] = pd.to_numeric(df['Target'], errors='coerce').astype(float)

# Drop rows where target is NaN
df = df.dropna(subset=['Target'])

# Now extract X and y
X = df[feature_cols].copy()
y = df['Target'].copy()

# Fill missing values with column mean (only numeric columns now)
X = X.fillna(X.mean())

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

# Statsmodels Logistic Regression (for p-values)
X_train_sm = sm.add_constant(X_train)
model_sm = sm.Logit(y_train, X_train_sm).fit(disp=False)
print("\n=== Statsmodels Summary ===")
print(model_sm.summary())

# Extract p-values
p_values = model_sm.pvalues

# Scikit-learn model for ROC
model_sk = LogisticRegression(max_iter=1000, random_state=42)
model_sk.fit(X_train, y_train)
y_pred_prob = model_sk.predict_proba(X_test)[:, 1]
auc = roc_auc_score(y_test, y_pred_prob)

# ROC Curve
fpr, tpr, _ = roc_curve(y_test, y_pred_prob)
plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, label=f'Logistic Regression (AUC = {auc:.3f})', linewidth=2)
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve - Readmission Prediction')
plt.legend()
plt.tight_layout()
plt.savefig('../outputs/roc_curve.png')
plt.close()

# Chi-square test for categorical variables (using int conversion)
categorical = ['Diabetes', 'Hypertension', 'COPD', 'CKD']
chi2_results = {}
for col in categorical:
    if col in df.columns:
        # Convert to integer, drop NaN
        x_vals = pd.to_numeric(df[col], errors='coerce')
        y_vals = df['Target']
        # Drop where either is NaN
        mask = ~(x_vals.isna() | y_vals.isna())
        if mask.sum() > 0:
            contingency = pd.crosstab(x_vals[mask], y_vals[mask])
            chi2, p, dof, expected = stats.chi2_contingency(contingency)
            chi2_results[col] = {'chi2': chi2, 'p_value': p}

# ANOVA for age by readmission
age_0 = df[df['Target'] == 0]['Age'].dropna()
age_1 = df[df['Target'] == 1]['Age'].dropna()
anova_result = stats.f_oneway(age_0, age_1) if len(age_0) > 0 and len(age_1) > 0 else (np.nan, np.nan)

# Save results
results = {
    'auc': auc,
    'p_values': p_values.to_dict(),
    'chi2_results': chi2_results,
    'anova_p': anova_result.pvalue if not np.isnan(anova_result.pvalue) else None
}
pd.to_pickle(results, '../outputs/statistical_results.pkl')

# Save text summary
with open('../outputs/statistical_summary.txt', 'w') as f:
    f.write(f"Logistic Regression AUC: {auc:.3f}\n")
    f.write(f"ANOVA p-value for Age: {anova_result.pvalue if not np.isnan(anova_result.pvalue) else 'N/A'}\n")
    f.write("\nChi-square test results:\n")
    for col, res in chi2_results.items():
        f.write(f"  {col}: chi2={res['chi2']:.2f}, p={res['p_value']:.4f}\n")
    f.write("\nTop 5 significant predictors (p-value):\n")
    # Remove constant
    p_vals_no_const = {k:v for k,v in p_values.items() if k != 'const'}
    sorted_p = sorted(p_vals_no_const.items(), key=lambda x: x[1])[:5]
    for var, pval in sorted_p:
        f.write(f"  {var}: {pval:.4e}\n")

print(f"\n✅ Statistical analysis complete. AUC = {auc:.3f}")
print("Results saved to ../outputs/statistical_results.pkl and statistical_summary.txt")