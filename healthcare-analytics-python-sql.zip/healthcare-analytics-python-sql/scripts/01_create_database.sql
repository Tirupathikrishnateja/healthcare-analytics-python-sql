CREATE DATABASE HealthcareAnalytics;
GO

USE HealthcareAnalytics;
GO

-- Dimension tables
CREATE TABLE DimPatient (
    PatientID INT PRIMARY KEY,
    Age INT,
    Gender VARCHAR(10),
    Race VARCHAR(30),
    InsuranceType VARCHAR(30),
    SmokingStatus VARCHAR(20),
    Diabetes CHAR(1),
    Hypertension CHAR(1),
    COPD CHAR(1),
    CKD CHAR(1),  -- Chronic Kidney Disease
    BMI DECIMAL(5,2)
);

CREATE TABLE DimHospital (
    HospitalID INT PRIMARY KEY,
    HospitalName VARCHAR(100),
    City VARCHAR(50),
    BedCapacity INT
);

CREATE TABLE DimDate (
    DateKey INT PRIMARY KEY,
    FullDate DATE,
    Year INT,
    Month INT,
    DayOfWeek INT,
    IsWeekend BIT
);

-- Fact tables
CREATE TABLE FactEncounter (
    EncounterID INT PRIMARY KEY,
    PatientID INT FOREIGN KEY REFERENCES DimPatient(PatientID),
    HospitalID INT FOREIGN KEY REFERENCES DimHospital(HospitalID),
    AdmissionDate DATE,
    DischargeDate DATE,
    LengthOfStay INT,
    PrimaryDiagnosis VARCHAR(100),
    Readmitted30Day BIT,
    ReadmissionDate DATE,
    MortalityFlag BIT,
    TotalCharge DECIMAL(10,2)
);

CREATE TABLE FactMedication (
    MedicationID INT PRIMARY KEY,
    EncounterID INT FOREIGN KEY REFERENCES FactEncounter(EncounterID),
    DrugName VARCHAR(100),
    DrugClass VARCHAR(50),
    DosageMg INT,
    DaysSupply INT
);

CREATE TABLE FactLabResult (
    LabID INT PRIMARY KEY,
    EncounterID INT FOREIGN KEY REFERENCES FactEncounter(EncounterID),
    LabTest VARCHAR(50),
    ResultValue DECIMAL(10,2),
    NormalRangeLow DECIMAL(10,2),
    NormalRangeHigh DECIMAL(10,2),
    AbnormalFlag BIT
);

CREATE INDEX idx_encounter_patient ON FactEncounter(PatientID);
CREATE INDEX idx_encounter_date ON FactEncounter(AdmissionDate);


