import pandas as pd
from sqlalchemy import create_engine
from lifelines import KaplanMeierFitter, CoxPHFitter
import matplotlib.pyplot as plt
import numpy as np

conn_str = "mssql+pyodbc://@SMASH/HealthcareAnalytics?driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes"
engine = create_engine(conn_str)

# Get time-to-readmission data
query = """
SELECT 
    e.PatientID,
    e.AdmissionDate,
    e.DischargeDate,
    e.Readmitted30Day,
    e.ReadmissionDate,
    DATEDIFF(day, e.DischargeDate, ISNULL(e.ReadmissionDate, DATEADD(day, 30, e.DischargeDate))) AS TimeToEvent,
    p.Age, p.Gender, p.Diabetes, p.Hypertension, p.CKD,
    m.DrugClass
FROM FactEncounter e
JOIN DimPatient p ON e.PatientID = p.PatientID
LEFT JOIN FactMedication m ON e.EncounterID = m.EncounterID
WHERE e.Readmitted30Day IS NOT NULL
"""
df = pd.read_sql(query, engine)

# Kaplan-Meier by drug class
kmf = KaplanMeierFitter()
plt.figure(figsize=(10,6))

for drug in df['DrugClass'].unique():
    subset = df[df['DrugClass'] == drug]
    kmf.fit(subset['TimeToEvent'], event_observed=subset['Readmitted30Day'], label=drug)
    kmf.plot_survival_function()

plt.title('Kaplan-Meier Survival Curves by Drug Class')
plt.xlabel('Days to Readmission')
plt.ylabel('Survival Probability')
plt.legend()
plt.savefig('../outputs/km_curves.png')
plt.close()

# Cox Proportional Hazards model
cox_data = df[['TimeToEvent', 'Readmitted30Day', 'Age', 'Diabetes', 'Hypertension', 'CKD']].dropna()
cph = CoxPHFitter()
cph.fit(cox_data, duration_col='TimeToEvent', event_col='Readmitted30Day')
cph.print_summary()
# Save summary plot
cph.plot()
plt.savefig('../outputs/cox_hazard_plot.png')
plt.close()

# Save Cox results
cox_summary = cph.summary
cox_summary.to_csv('../outputs/cox_summary.csv')
print("✅ Survival analysis complete.")


