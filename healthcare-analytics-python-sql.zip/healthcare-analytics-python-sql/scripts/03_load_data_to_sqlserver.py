    # 03_load_data_to_sqlserver.py
import pandas as pd
from sqlalchemy import create_engine, text
import os

# Connection string for SMASH (default instance, Windows Authentication)
conn_str = "mssql+pyodbc://@SMASH/HealthcareAnalytics?driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes"
engine = create_engine(conn_str)

def clear_tables_safely():
    """Clear all tables in correct order (children first) to avoid foreign key conflicts"""
    with engine.connect() as conn:
        # Disable all constraints temporarily
        conn.execute(text("EXEC sp_msforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'"))
        
        # Delete data in correct order (dependent tables first)
        conn.execute(text("DELETE FROM FactLabResult"))
        conn.execute(text("DELETE FROM FactMedication"))
        conn.execute(text("DELETE FROM FactEncounter"))
        conn.execute(text("DELETE FROM DimPatient"))
        conn.execute(text("DELETE FROM DimHospital"))
        conn.execute(text("DELETE FROM DimDate"))  # if used
        
        # Re-enable constraints
        conn.execute(text("EXEC sp_msforeachtable 'ALTER TABLE ? CHECK CONSTRAINT ALL'"))
        conn.commit()
        print("✅ Cleared existing data from all tables.")

# Only clear if we are reloading (optional, but good for fresh loads)
clear_tables_safely()

# Define files and their corresponding table names
files = [
    ('../data/raw/DimPatient.csv', 'DimPatient'),
    ('../data/raw/DimHospital.csv', 'DimHospital'),
    ('../data/raw/FactEncounter.csv', 'FactEncounter'),
    ('../data/raw/FactMedication.csv', 'FactMedication'),
    ('../data/raw/FactLabResult.csv', 'FactLabResult')
]

# Load each CSV into its table
for file_path, table_name in files:
    if os.path.exists(file_path):
        df = pd.read_csv(file_path)
        
        # Convert date columns if they exist in this table
        date_columns = ['AdmissionDate', 'DischargeDate', 'ReadmissionDate']
        for col in date_columns:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors='coerce').dt.date
        
        # Load into SQL Server (append because tables already exist from DDL)
        df.to_sql(table_name, engine, if_exists='append', index=False)
        print(f"Loaded {len(df)} rows into {table_name}")
    else:
        print(f"Warning: {file_path} not found. Skipping {table_name}.")

print("✅ All healthcare data loaded successfully into SQL Server.")


