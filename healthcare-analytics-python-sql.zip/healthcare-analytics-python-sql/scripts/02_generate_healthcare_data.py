# 02_generate_healthcare_data.py (Corrected)
import pandas as pd
import numpy as np
from faker import Faker
from datetime import datetime, timedelta
import random
import os

fake = Faker()
np.random.seed(2024)
random.seed(2024)

os.makedirs('../data/raw', exist_ok=True)

# Time period: 2 years
end_date = datetime.now().date()
start_date = end_date - timedelta(days=730)

# 1. Generate 5000 patients with realistic demographics and comorbidities
patients = []
for i in range(1, 5001):
    age = np.random.normal(65, 15)  # mean 65, std 15
    age = max(18, min(100, int(age)))
    
    # Comorbidities with realistic correlations
    diabetes = 1 if np.random.random() < (0.3 if age > 50 else 0.1) else 0
    hypertension = 1 if np.random.random() < (0.5 if age > 60 else 0.2) else 0
    copd = 1 if np.random.random() < (0.15 if age > 50 else 0.05) else 0
    ckd = 1 if np.random.random() < (0.12 if diabetes else 0.03) else 0
    
    bmi = np.random.normal(28, 5)
    bmi = max(18, min(50, round(bmi, 1)))
    
    patients.append({
        'PatientID': i,
        'Age': age,
        'Gender': random.choice(['M', 'F']),
        'Race': random.choice(['White', 'Black', 'Hispanic', 'Asian', 'Other']),
        'InsuranceType': random.choices(['Medicare', 'Medicaid', 'Private', 'Uninsured'], weights=[0.45,0.25,0.2,0.1])[0],
        'SmokingStatus': random.choices(['Never', 'Former', 'Current'], weights=[0.5,0.3,0.2])[0],
        'Diabetes': diabetes,
        'Hypertension': hypertension,
        'COPD': copd,
        'CKD': ckd,
        'BMI': bmi
    })
df_patient = pd.DataFrame(patients)

# 2. Generate hospitals
hospitals = []
for i in range(1, 6):
    hospitals.append({
        'HospitalID': i,
        'HospitalName': f"{fake.city()} Medical Center",
        'City': fake.city(),
        'BedCapacity': random.randint(200, 800)
    })
df_hospital = pd.DataFrame(hospitals)

# 3. Generate encounters (admissions)
encounters = []
encounter_id = 10000
readmission_risk_base = 0.18  # baseline readmission rate

for pat_id, patient in df_patient.iterrows():
    patient_id = patient['PatientID']
    age = patient['Age']
    diabetes = patient['Diabetes']
    hypertension = patient['Hypertension']
    copd = patient['COPD']
    ckd = patient['CKD']
    smoking = patient['SmokingStatus']
    
    # Number of admissions per patient (1-4 over 2 years)
    num_admissions = np.random.poisson(1.5) + 1
    num_admissions = min(num_admissions, 4)
    
    admission_dates = sorted([fake.date_between(start_date, end_date) for _ in range(num_admissions)])
    
    for idx, adm_date in enumerate(admission_dates):
        # Length of stay (log-normal distribution)
        los = int(np.random.lognormal(mean=1.5, sigma=0.7)) + 1
        los = min(los, 30)
        discharge_date = adm_date + timedelta(days=los)
        
        # Primary diagnosis (cardiology focus)
        diagnosis = random.choices(['Heart Failure', 'Pneumonia', 'COPD Exacerbation', 'Sepsis', 'MI', 'Stroke', 'CKD'], 
                                   weights=[0.25, 0.2, 0.15, 0.1, 0.1, 0.1, 0.1])[0]
        
        # Readmission risk model (logistic function)
        log_odds = -2.5 + 0.03*age + 0.5*diabetes + 0.6*hypertension + 0.4*copd + 0.7*ckd
        if smoking == 'Current':
            log_odds += 0.4
        if diagnosis == 'Heart Failure':
            log_odds += 0.8
        if los > 7:
            log_odds += 0.5
        
        risk = 1 / (1 + np.exp(-log_odds))
        readmitted = 1 if np.random.random() < risk else 0
        
        readmission_date = None
        if readmitted and idx + 1 < len(admission_dates):
            next_adm = admission_dates[idx+1]
            if (next_adm - adm_date).days <= 30:
                readmission_date = next_adm
            else:
                readmitted = 0
        
        mortality = 1 if (readmitted and np.random.random() < 0.05) or (los > 14 and np.random.random() < 0.03) else 0
        
        # Total charge based on LOS and diagnosis
        charge = 5000 + los * 2000 + (10000 if diagnosis == 'Sepsis' else 0)
        charge = round(charge + np.random.normal(0, 1000), 2)
        
        encounters.append({
            'EncounterID': encounter_id,
            'PatientID': patient_id,
            'HospitalID': random.randint(1, 5),
            'AdmissionDate': adm_date,
            'DischargeDate': discharge_date,
            'LengthOfStay': los,
            'PrimaryDiagnosis': diagnosis,
            'Readmitted30Day': readmitted,
            'ReadmissionDate': readmission_date,
            'MortalityFlag': mortality,
            'TotalCharge': charge
        })
        encounter_id += 1

df_encounter = pd.DataFrame(encounters)

# 4. Generate medications (for each encounter)
medications = []
med_id = 50000
drugs = [
    ('Lisinopril', 'ACE Inhibitor'), ('Metoprolol', 'Beta Blocker'), ('Furosemide', 'Diuretic'),
    ('Atorvastatin', 'Statin'), ('Aspirin', 'Antiplatelet'), ('Warfarin', 'Anticoagulant'),
    ('Metformin', 'Antidiabetic'), ('Albuterol', 'Bronchodilator'), ('Prednisone', 'Corticosteroid')
]

for _, enc in df_encounter.iterrows():
    num_drugs = random.randint(1, 4)
    selected = random.sample(drugs, num_drugs)
    for drug, drug_class in selected:
        medications.append({
            'MedicationID': med_id,
            'EncounterID': enc['EncounterID'],
            'DrugName': drug,
            'DrugClass': drug_class,
            'DosageMg': random.choice([5,10,20,40,80]),
            'DaysSupply': min(enc['LengthOfStay'] + random.randint(0, 14), 90)
        })
        med_id += 1
df_medication = pd.DataFrame(medications)

# 5. Generate lab results
labs = []
lab_id = 100000
lab_tests = ['Hemoglobin', 'Creatinine', 'BNP', 'Troponin', 'Glucose']

for _, enc in df_encounter.iterrows():
    num_labs = random.randint(2, 5)
    for test in random.sample(lab_tests, num_labs):
        if test == 'Hemoglobin':
            value = np.random.normal(12, 2)
            normal_low, normal_high = 12, 16
        elif test == 'Creatinine':
            value = np.random.normal(1.0, 0.5)
            normal_low, normal_high = 0.6, 1.2
        elif test == 'BNP':
            value = np.random.lognormal(mean=4.5, sigma=1.0)
            normal_low, normal_high = 0, 100
        elif test == 'Troponin':
            value = np.random.lognormal(mean=0.5, sigma=0.8)
            normal_low, normal_high = 0, 0.04
        else:  # Glucose
            value = np.random.normal(110, 40)
            normal_low, normal_high = 70, 140
        
        abnormal = 1 if (value < normal_low or value > normal_high) else 0
        labs.append({
            'LabID': lab_id,
            'EncounterID': enc['EncounterID'],
            'LabTest': test,
            'ResultValue': round(value, 2),
            'NormalRangeLow': normal_low,
            'NormalRangeHigh': normal_high,
            'AbnormalFlag': abnormal
        })
        lab_id += 1
df_lab = pd.DataFrame(labs)

# Save to CSV
df_patient.to_csv('../data/raw/DimPatient.csv', index=False)
df_hospital.to_csv('../data/raw/DimHospital.csv', index=False)
df_encounter.to_csv('../data/raw/FactEncounter.csv', index=False)
df_medication.to_csv('../data/raw/FactMedication.csv', index=False)
df_lab.to_csv('../data/raw/FactLabResult.csv', index=False)

print("✅ Healthcare dataset generated:")
print(f"Patients: {len(df_patient)}")
print(f"Encounters: {len(df_encounter)}")
print(f"Medications: {len(df_medication)}")
print(f"Lab results: {len(df_lab)}")
print(f"Date range: {df_encounter['AdmissionDate'].min()} to {df_encounter['AdmissionDate'].max()}")
print(f"Readmission rate: {df_encounter['Readmitted30Day'].mean():.2%}")